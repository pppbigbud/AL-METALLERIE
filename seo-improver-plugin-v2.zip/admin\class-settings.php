<?php
/**
 * Settings API
 * 
 * @package Almetal_Analytics
 */

if (!defined('ABSPATH')) {
    exit;
}

class Almetal_Analytics_Settings {
    // Placeholder - settings are handled in class-admin.php
}
