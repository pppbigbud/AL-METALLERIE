<?php
/**
 * Opportunities view for Smart Backlink Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Opportunities view - sera complété plus tard -->
