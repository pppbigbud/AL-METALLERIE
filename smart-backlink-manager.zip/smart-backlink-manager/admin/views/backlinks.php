<?php
/**
 * Backlinks view for Smart Backlink Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Backlinks view - sera complété plus tard -->
