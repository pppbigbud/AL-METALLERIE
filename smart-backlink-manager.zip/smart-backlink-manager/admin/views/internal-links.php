<?php
/**
 * Internal Links view for Smart Backlink Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Internal Links view - sera complété plus tard -->
