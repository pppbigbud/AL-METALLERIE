<?php
/**
 * Dashboard view for Smart Backlink Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Dashboard view - sera complété plus tard -->
