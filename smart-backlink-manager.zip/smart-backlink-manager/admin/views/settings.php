<?php
/**
 * Settings view for Smart Backlink Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!-- Settings view - sera complété plus tard -->
