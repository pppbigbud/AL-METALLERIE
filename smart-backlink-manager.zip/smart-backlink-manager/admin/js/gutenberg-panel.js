// Gutenberg panel script for Smart Backlink Manager
// Sera complété plus tard
