# Smart Backlink Manager

Plugin WordPress pour la gestion intelligente des backlinks et liens internes.

## Installation
1. Copiez le dossier dans wp-content/plugins/
2. Activez le plugin dans l'administration WordPress

## Fonctionnalités
- Gestion des backlinks
- Suggestions de liens internes
- Dashboard analytique
- Tracking des opportunités

## Support
AL Métallerie - https://al-metallerie.fr
